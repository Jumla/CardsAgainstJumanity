var socket = io();
var identity = null;


$("nav").hide();
$("#usercard").hide();
$( document ).ready(function() {
    $("#username").submit(function (event) {
        event.preventDefault();
        $("#identity").fadeOut();
        identity = $("#name").val();
        socket.emit('user identify', identity);
        $("nav").show();
    });
});


socket.on('user update', function(msg){
    if(identity === null)
        return;

    console.log(msg.users);

    $('#connected').text("");

    var message = msg.user + " has ";
    if(msg.action === "join")
        message = message + "joined";
    else
        message = message + "left";

    Materialize.toast(message, 200);

    for(var user in msg.users) {
        var name = msg.users[user];
        if(name === "")
            continue;
        var usercard = $('#usercard').clone();
        usercard.attr("id", name);
        usercard.value = name;
        usercard.show();
        $('#connected').append(usercard[0].outerHTML);
        $('#' + name).text(name);
    }
});