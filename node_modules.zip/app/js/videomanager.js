var socket = io();


$("#videocard").hide();
$( document ).ready(function() {
    $("#linkform").submit(function( event ) {
        event.preventDefault();
        addVideo($("#youtubelink").val());
    });

    $("#videos").on('click', '#play', function(event) {
        syncNewVideo(event.target.getAttribute("href").replace("#", ""));
        return false;
    });

    $("#videos").on('click', '#delete', function(event) {//
        $(event.target.getAttribute("href")).fadeOut();
        return false;
    });
});



function addVideo(url) {
    var id = getId(url);
    if(id === null)
        return;
    var data = getData(id);
}


function getData(id) {
    $.get( "https://www.googleapis.com/youtube/v3/videos?key=AIzaSyBh241tggjoBvUHgTWEQKEzFJnWHSh7FaI&part=snippet&id=" + id).done( function( data ) {
        addCard(id, data);
    });
}

function getId(url) {
    try {
        var video_id = url.split('v=')[1];
        var ampersandPosition = video_id.indexOf('&');
        if(ampersandPosition != -1) {
            video_id = video_id.substring(0, ampersandPosition);
        }
        return video_id;
    }  catch(err) {
        console.log(err);
        Materialize.toast("That's not a valid Youtube video...", 4000);
        return null;
    }
}

function addCard(id, data) {
    Materialize.toast("Added video...", 4000);
    var card = $('#videocard').clone();
    card.attr("id",id);
    card.find("#title").text(JSON.stringify(data['items'][0]['snippet']['title']));
    card.find("#cardimage").attr("src", data['items'][0]['snippet']['thumbnails']['medium']['url']);
    card.find("#play").attr("href", "#" + id);
    card.find("#delete").attr("href", "#" + id);
    card.show();
    $('#videos').append(card[0].outerHTML);
}