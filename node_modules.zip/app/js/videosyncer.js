var socket = io();
var currentId = null;
var currentData = null;

//Load youtube API
var tag = document.createElement('script');

tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

var player = null;
var sync = null;
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
        width: '853',
        height: '480',
        events: {
            'onStateChange': onStateChange
        }
    });
}

function syncNewVideo(id) {
    socket.emit('new video', id);
}



socket.on('sync video', function(msg){
    if(currentId != msg.id) {
        currentId = msg.id;
        processData(currentId);
        player.loadVideoById(msg.id);
    }

    if(player.getPlayerState() == 1 && msg.playing == false) {
        player.pauseVideo();
    }
    if(player.getPlayerState() == 2 && msg.playing == true) {
        player.playVideo();
    }

    if(Math.round(player.getCurrentTime()) != Math.round(msg.time))
        player.seekTo(msg.time);
});

function onStateChange(event) {
    if(event == null)
        return;
    if (event.data === 1) {
        socket.emit('play', player.getCurrentTime());
    }
    else if (event.data === 2) {
        socket.emit('pause', player.getCurrentTime());
    }
}

function requestCurrent() {
    socket.emit('request update');
}

function processData(id) {
    $.get( "https://www.googleapis.com/youtube/v3/videos?key=AIzaSyBh241tggjoBvUHgTWEQKEzFJnWHSh7FaI&part=snippet&id=" + id).done( function( data ) {
        currentData = data;
        processData();
    });
}

function processData() {
    //$("#vidtitle").text(JSON.stringify(currentData['items'][0]['snippet']['title']));
}
