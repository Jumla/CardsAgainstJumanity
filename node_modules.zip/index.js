var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var users = new Array();

var videoId = null;
var videoTime = 0;
var videoPlaying = false;


app.use('/', express.static(__dirname + '/app'));
app.set("/","apps/");

app.get('/', function(req, res){
  res.sendfile('index.html');
});


io.on('connection', function(socket){
    console.log('An unauthenticated user connected: ' + socket.request.connection.remoteAddress);
    socket.on('disconnect', function(){
        if(socket.username == null)
            console.log('Unauthenticated user disconnected');
        else {
            console.log(socket.username + " disconnected.");
            users.splice(users.indexOf(socket.username), 1);
            io.emit('user update', { user: socket.username, action: "leave", users: users, for: 'everyone' });
        }
    });

    socket.on('user identify', function(username){
        console.log(socket.request.connection.remoteAddress + " is now " + username);
        users.push(username);
        io.emit('user update', { user: username, action: "join", users: users, for: 'everyone' });
        socket.username = username;
        socket.emit('sync video', {id: videoId, time: videoTime, playing: videoPlaying});
    });

    socket.on('new video', function(id){
        console.log(socket.username + " has synced up " + id);
        videoId = id;
        videoTime = 0;
        videoPlaying = false;
        console.log(videoId);
        io.emit('sync video', { id: videoId, time: videoTime, playing: videoPlaying, for: 'everyone' });
    });

    socket.on('play', function(time){
        videoTime = time;
        videoPlaying = true;
        io.emit('sync video', { id: videoId, time: videoTime, playing: videoPlaying, for: 'everyone' });
    });

    socket.on('pause', function(time){
        videoTime = time;
        videoPlaying = false;
        io.emit('sync video', { id: videoId, time: videoTime, playing: videoPlaying, for: 'everyone' });
    });


    socket.on('request update', function(id){
        socket.emit('sync video', { id: videoId, time: videoTime, playing: videoPlaying});
    });
});

http.listen(82, function(){
  console.log('listening on *:82');
});


function incrementTime() {
    if(!videoPlaying)
        return;
    videoTime = videoTime + 1;
    if(videoTime % 60 === 0) {
        console.log(this.id + " is at " + videoTime);
    }
}
setInterval(incrementTime, 1*1000);
